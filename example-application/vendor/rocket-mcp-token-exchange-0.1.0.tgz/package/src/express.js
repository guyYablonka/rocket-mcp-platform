import { createTokenExchange } from "./core.js";

export function tokenExchangeExpress(options) {
  const handle = createTokenExchange(options);
  return async function tokenExchangeMiddleware(request, response, next) {
    try {
      const result = await handle({
        headers: request.headers,
        body: request.body,
        ip: request.ip || request.socket?.remoteAddress || "",
      });
      for (const [name, value] of Object.entries(result.headers)) response.setHeader(name, value);
      response.status(result.status).json(result.body);
    } catch (error) {
      next(error);
    }
  };
}

export default tokenExchangeExpress;
