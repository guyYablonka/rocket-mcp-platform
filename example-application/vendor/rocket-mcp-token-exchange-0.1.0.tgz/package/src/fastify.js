import { createTokenExchange } from "./core.js";

export async function tokenExchangeFastify(fastify, options) {
  const { path = "/api/auth/mcp-token", ...coreOptions } = options;
  const handle = createTokenExchange(coreOptions);
  fastify.post(path, {
    schema: {
      response: {
        200: {
          type: "object",
          required: ["accessToken", "tokenType", "expiresIn", "scopes"],
          properties: {
            accessToken: { type: "string" },
            tokenType: { type: "string" },
            expiresIn: { type: "number" },
            scopes: { type: "array", items: { type: "string" } },
          },
        },
      },
    },
  }, async (request, reply) => {
    const result = await handle({
      headers: request.headers,
      body: request.body,
      ip: request.ip || request.socket?.remoteAddress || "",
    });
    for (const [name, value] of Object.entries(result.headers)) reply.header(name, value);
    return reply.code(result.status).send(result.body);
  });
}

export default tokenExchangeFastify;
