import { Controller, Inject, Injectable, Module, Post, Req, Res } from "@nestjs/common";
import { createTokenExchange } from "./core.js";

const TOKEN_EXCHANGE_OPTIONS = Symbol("TOKEN_EXCHANGE_OPTIONS");

class TokenExchangeService {
  constructor(options) {
    const { path: _path, ...coreOptions } = options;
    this.handle = createTokenExchange(coreOptions);
  }
}
Injectable()(TokenExchangeService);
Inject(TOKEN_EXCHANGE_OPTIONS)(TokenExchangeService, undefined, 0);

export class TokenExchangeModule {
  static register(options) {
    const path = options.path || "/api/auth/mcp-token";

    class TokenExchangeController {
      constructor(service) {
        this.service = service;
      }

      async exchange(request, response) {
        const result = await this.service.handle({
          headers: request.headers,
          body: request.body,
          ip: request.ip || request.socket?.remoteAddress || "",
        });
        for (const [name, value] of Object.entries(result.headers)) {
          if (typeof response.setHeader === "function") response.setHeader(name, value);
          else if (typeof response.header === "function") response.header(name, value);
        }
        if (typeof response.status === "function") response.status(result.status);
        else if (typeof response.code === "function") response.code(result.status);
        return result.body;
      }
    }

    Inject(TokenExchangeService)(TokenExchangeController, undefined, 0);
    Controller()(TokenExchangeController);
    Post(path)(TokenExchangeController.prototype, "exchange", Object.getOwnPropertyDescriptor(TokenExchangeController.prototype, "exchange"));
    Req()(TokenExchangeController.prototype, "exchange", 0);
    Res({ passthrough: true })(TokenExchangeController.prototype, "exchange", 1);

    return {
      module: TokenExchangeModule,
      providers: [
        { provide: TOKEN_EXCHANGE_OPTIONS, useValue: options },
        TokenExchangeService,
      ],
      controllers: [TokenExchangeController],
    };
  }
}
Module({})(TokenExchangeModule);

export default TokenExchangeModule;
