import { createHash, randomUUID, timingSafeEqual } from "node:crypto";

const NO_STORE_HEADERS = Object.freeze({
  "Cache-Control": "no-store",
  Pragma: "no-cache",
  "Content-Type": "application/json",
});

function response(status, body, headers = {}) {
  return { status, headers: { ...NO_STORE_HEADERS, ...headers }, body };
}

function errorResponse(status, error, description, requestId, headers = {}) {
  return response(status, { error, error_description: description, requestId }, headers);
}

function header(headers, name) {
  if (!headers) return undefined;
  const value = headers[name] ?? headers[name.toLowerCase()];
  return Array.isArray(value) ? value[0] : value;
}

function validString(value, maxLength = 256) {
  return typeof value === "string" && value.length > 0 && value.length <= maxLength;
}

function normalizeScopes(value, maxScopes) {
  if (!Array.isArray(value) || value.length > maxScopes) return undefined;
  const scopes = value.map((scope) => typeof scope === "string" ? scope.trim() : "");
  if (scopes.some((scope) => !scope || scope.length > 128 || !/^[A-Za-z0-9:._/-]+$/.test(scope))) return undefined;
  return [...new Set(scopes)];
}

function normalizeActor(value, required) {
  if (!value && !required) return {};
  if (!value || typeof value !== "object" || Array.isArray(value)) return undefined;
  const allowed = ["rocketUserId", "tenantId", "roomId", "requestId"];
  if (Object.keys(value).some((key) => !allowed.includes(key))) return undefined;
  if (!validString(value.rocketUserId) || !validString(value.tenantId) || !validString(value.requestId)) return undefined;
  if (value.roomId !== undefined && !validString(value.roomId)) return undefined;
  return Object.freeze({
    rocketUserId: value.rocketUserId,
    tenantId: value.tenantId,
    roomId: value.roomId || "",
    requestId: value.requestId,
  });
}

function validateOptions(options) {
  for (const name of ["authenticateGateway", "findUser", "authorizeScopes", "issueToken"]) {
    if (typeof options?.[name] !== "function") throw new TypeError(`${name} must be a function`);
  }
}

export function createTokenExchange(options) {
  validateOptions(options);
  const maxScopes = options.maxScopes || 32;
  const requireActor = options.requireActor !== false;
  const audit = typeof options.audit === "function" ? options.audit : () => {};
  const emit = async (event) => {
    try { await audit(event); } catch {}
  };

  return async function handleTokenExchange(input) {
    const requestId = validString(input?.body?.actor?.requestId)
      ? input.body.actor.requestId
      : validString(header(input?.headers, "x-request-id")) ? header(input.headers, "x-request-id") : randomUUID();
    const context = Object.freeze({ requestId, ip: input?.ip || "", userAgent: header(input?.headers, "user-agent") || "" });

    let gateway;
    try {
      gateway = await options.authenticateGateway({
        authorization: header(input?.headers, "authorization"),
        headers: input?.headers || {},
        context,
      });
    } catch (error) {
      await emit({ type: "gateway_auth_error", requestId, error: error.message });
      return errorResponse(500, "server_error", "Gateway authentication failed unexpectedly", requestId);
    }
    if (!gateway) {
      await emit({ type: "gateway_auth_denied", requestId, ip: context.ip });
      return errorResponse(401, "invalid_client", "Gateway authentication failed", requestId, {
        "WWW-Authenticate": 'Bearer realm="mcp-token-exchange"',
      });
    }

    const body = input?.body;
    if (!body || typeof body !== "object" || Array.isArray(body)) {
      return errorResponse(400, "invalid_request", "A JSON request body is required", requestId);
    }
    const allowedBodyFields = ["applicationUserId", "requestedScopes", "actor"];
    if (Object.keys(body).some((key) => !allowedBodyFields.includes(key))) {
      return errorResponse(400, "invalid_request", "The request contains unsupported fields", requestId);
    }
    if (!validString(body.applicationUserId)) {
      return errorResponse(400, "invalid_request", "applicationUserId is required", requestId);
    }
    const requestedScopes = normalizeScopes(body.requestedScopes, maxScopes);
    if (!requestedScopes) {
      return errorResponse(400, "invalid_scope", "requestedScopes is invalid", requestId);
    }
    const actor = normalizeActor(body.actor, requireActor);
    if (!actor) {
      return errorResponse(400, "invalid_request", "actor identity is invalid", requestId);
    }

    let user;
    try {
      user = await options.findUser({ applicationUserId: body.applicationUserId, actor, gateway, context });
    } catch (error) {
      await emit({ type: "user_lookup_error", requestId, gatewayId: gateway.id, error: error.message });
      return errorResponse(500, "server_error", "User lookup failed unexpectedly", requestId);
    }
    if (!user || user.disabled) {
      await emit({ type: "exchange_denied", reason: "user_unavailable", requestId, gatewayId: gateway.id });
      return errorResponse(403, "access_denied", "The delegated user is unavailable", requestId);
    }

    let grantedScopes;
    try {
      grantedScopes = normalizeScopes(await options.authorizeScopes({ user, requestedScopes, actor, gateway, context }), maxScopes);
    } catch (error) {
      await emit({ type: "scope_authorization_error", requestId, gatewayId: gateway.id, error: error.message });
      return errorResponse(500, "server_error", "Scope authorization failed unexpectedly", requestId);
    }
    const grantedSet = new Set(grantedScopes || []);
    if (!grantedScopes || requestedScopes.some((scope) => !grantedSet.has(scope))) {
      await emit({ type: "exchange_denied", reason: "insufficient_scope", requestId, gatewayId: gateway.id });
      return errorResponse(403, "invalid_scope", "One or more requested scopes are not permitted", requestId);
    }

    let token;
    try {
      token = await options.issueToken({ user, scopes: requestedScopes, actor, gateway, context });
    } catch (error) {
      await emit({ type: "token_issue_error", requestId, gatewayId: gateway.id, error: error.message });
      return errorResponse(500, "server_error", "Token issuance failed unexpectedly", requestId);
    }
    if (!validString(token?.accessToken, 16_384) || !Number.isFinite(token?.expiresIn) || token.expiresIn < 1) {
      await emit({ type: "token_issue_invalid", requestId, gatewayId: gateway.id });
      return errorResponse(500, "server_error", "Token issuer returned an invalid result", requestId);
    }

    await emit({
      type: "exchange_succeeded",
      requestId,
      gatewayId: gateway.id,
      applicationUserId: body.applicationUserId,
      scopes: requestedScopes,
      expiresIn: token.expiresIn,
    });
    return response(200, {
      accessToken: token.accessToken,
      tokenType: token.tokenType || "Bearer",
      expiresIn: token.expiresIn,
      scopes: requestedScopes,
    });
  };
}

function bearer(value) {
  const match = /^Bearer\s+(.+)$/i.exec(String(value || ""));
  return match?.[1];
}

function digest(value) {
  return createHash("sha256").update(String(value)).digest();
}

export function createStaticGatewayAuthenticator({ tokens }) {
  const rawEntries = (tokens || []).map((entry, index) => typeof entry === "string"
    ? { id: `gateway-${index + 1}`, token: entry }
    : { id: entry?.id, token: entry?.token });
  if (!rawEntries.length || rawEntries.some((entry) => !validString(entry.id) || typeof entry.token !== "string" || entry.token.length < 16)) {
    throw new TypeError("At least one gateway token of 16 or more characters with a valid ID is required");
  }
  const entries = rawEntries.map((entry) => ({ id: entry.id, digest: digest(entry.token) }));

  return async ({ authorization }) => {
    const candidate = bearer(authorization);
    if (!candidate) return null;
    const candidateDigest = digest(candidate);
    let matched;
    for (const entry of entries) {
      if (timingSafeEqual(candidateDigest, entry.digest)) matched ||= entry;
    }
    return matched ? Object.freeze({ id: matched.id }) : null;
  };
}

export const tokenExchangeRequestSchema = Object.freeze({
  type: "object",
  additionalProperties: false,
  required: ["applicationUserId", "requestedScopes", "actor"],
  properties: {
    applicationUserId: { type: "string", minLength: 1, maxLength: 256 },
    requestedScopes: { type: "array", maxItems: 32, items: { type: "string", minLength: 1, maxLength: 128 } },
    actor: {
      type: "object",
      additionalProperties: false,
      required: ["rocketUserId", "tenantId", "requestId"],
      properties: {
        rocketUserId: { type: "string", minLength: 1, maxLength: 256 },
        tenantId: { type: "string", minLength: 1, maxLength: 256 },
        roomId: { type: "string", minLength: 1, maxLength: 256 },
        requestId: { type: "string", minLength: 1, maxLength: 256 },
      },
    },
  },
});
