import { createHmac, randomUUID, timingSafeEqual } from "node:crypto";

function encode(value) {
  return Buffer.from(JSON.stringify(value)).toString("base64url");
}

function signature(secret, input) {
  return createHmac("sha256", secret).update(input).digest();
}

function requireSecret(secret) {
  if (typeof secret !== "string" || secret.length < 32) throw new TypeError("JWT secret must contain at least 32 characters");
}

function audiencesMatch(actual, expected) {
  return Array.isArray(actual) ? actual.includes(expected) : actual === expected;
}

export function createHs256JwtIssuer(options) {
  requireSecret(options?.secret);
  if (!options.issuer || !options.audience) throw new TypeError("JWT issuer and audience are required");
  const ttlSeconds = options.ttlSeconds || 300;
  if (!Number.isInteger(ttlSeconds) || ttlSeconds < 1 || ttlSeconds > 3600) throw new TypeError("JWT ttlSeconds must be between 1 and 3600");
  const getSubject = options.getSubject || ((user) => user.id || user.applicationUserId || user.sub);

  return async ({ user, scopes, actor, gateway, context }) => {
    const subject = getSubject(user);
    if (typeof subject !== "string" || !subject) throw new Error("Token subject is missing");
    const now = Math.floor(Date.now() / 1000);
    const header = encode({ alg: "HS256", typ: "JWT", ...(options.keyId ? { kid: options.keyId } : {}) });
    const customClaims = typeof options.additionalClaims === "function"
      ? await options.additionalClaims({ user, scopes, actor, gateway, context })
      : options.additionalClaims || {};
    const reserved = new Set(["iss", "aud", "sub", "iat", "exp", "jti", "scope"]);
    if (Object.keys(customClaims).some((name) => reserved.has(name))) throw new Error("additionalClaims cannot override reserved JWT claims");
    const payload = encode({
      ...customClaims,
      iss: options.issuer,
      aud: options.audience,
      sub: subject,
      iat: now,
      exp: now + ttlSeconds,
      jti: randomUUID(),
      scope: scopes.join(" "),
    });
    const signed = `${header}.${payload}`;
    return {
      accessToken: `${signed}.${signature(options.secret, signed).toString("base64url")}`,
      tokenType: "Bearer",
      expiresIn: ttlSeconds,
      scopes,
    };
  };
}

export function verifyHs256Jwt(token, options, now = Math.floor(Date.now() / 1000)) {
  requireSecret(options?.secret);
  const parts = String(token || "").split(".");
  if (parts.length !== 3) throw new Error("Malformed JWT");
  const [encodedHeader, encodedPayload, encodedSignature] = parts;
  let header;
  let claims;
  try {
    header = JSON.parse(Buffer.from(encodedHeader, "base64url"));
    claims = JSON.parse(Buffer.from(encodedPayload, "base64url"));
  } catch {
    throw new Error("Malformed JWT payload");
  }
  if (header.alg !== "HS256" || header.typ !== "JWT") throw new Error("Unsupported JWT algorithm");
  const expected = signature(options.secret, `${encodedHeader}.${encodedPayload}`);
  const actual = Buffer.from(encodedSignature, "base64url");
  if (actual.length !== expected.length || !timingSafeEqual(actual, expected)) throw new Error("Invalid JWT signature");
  const skew = options.clockSkewSeconds || 0;
  if (claims.iss !== options.issuer) throw new Error("Invalid JWT issuer");
  if (!audiencesMatch(claims.aud, options.audience)) throw new Error("Invalid JWT audience");
  if (!Number.isFinite(claims.exp) || claims.exp <= now - skew) throw new Error("Expired JWT");
  if (!Number.isFinite(claims.iat) || claims.iat > now + skew) throw new Error("JWT issued in the future");
  if (typeof claims.sub !== "string" || !claims.sub) throw new Error("JWT subject is missing");
  return Object.freeze(claims);
}
