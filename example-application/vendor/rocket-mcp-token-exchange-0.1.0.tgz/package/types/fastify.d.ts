import type { FastifyPluginAsync } from "fastify";
import type { DelegatedUser, GatewayPrincipal, TokenExchangeOptions } from "./core.d.ts";

export type FastifyTokenExchangeOptions<User extends DelegatedUser = DelegatedUser, Gateway extends GatewayPrincipal = GatewayPrincipal> =
  TokenExchangeOptions<User, Gateway> & { path?: string };

export const tokenExchangeFastify: FastifyPluginAsync<FastifyTokenExchangeOptions>;
export default tokenExchangeFastify;
