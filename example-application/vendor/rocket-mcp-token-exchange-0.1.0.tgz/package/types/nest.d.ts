import type { DynamicModule } from "@nestjs/common";
import type { DelegatedUser, GatewayPrincipal, TokenExchangeOptions } from "./core.d.ts";

export type NestTokenExchangeOptions<User extends DelegatedUser = DelegatedUser, Gateway extends GatewayPrincipal = GatewayPrincipal> =
  TokenExchangeOptions<User, Gateway> & { path?: string };

export class TokenExchangeModule {
  static register<User extends DelegatedUser = DelegatedUser, Gateway extends GatewayPrincipal = GatewayPrincipal>(
    options: NestTokenExchangeOptions<User, Gateway>,
  ): DynamicModule;
}

export default TokenExchangeModule;
