import type { ActorIdentity, ExchangeContext, GatewayPrincipal, TokenResult } from "./core.d.ts";

export interface Hs256IssuerOptions<User = unknown> {
  secret: string;
  issuer: string;
  audience: string;
  ttlSeconds?: number;
  keyId?: string;
  getSubject?(user: User): string;
  additionalClaims?: Record<string, unknown> | ((input: {
    user: User;
    scopes: string[];
    actor: ActorIdentity;
    gateway: GatewayPrincipal;
    context: ExchangeContext;
  }) => Record<string, unknown> | Promise<Record<string, unknown>>);
}

export function createHs256JwtIssuer<User = unknown>(options: Hs256IssuerOptions<User>): (input: {
  user: User;
  scopes: string[];
  actor: ActorIdentity;
  gateway: GatewayPrincipal;
  context: ExchangeContext;
}) => Promise<TokenResult>;

export function verifyHs256Jwt(token: string, options: {
  secret: string;
  issuer: string;
  audience: string;
  clockSkewSeconds?: number;
}, now?: number): Readonly<Record<string, unknown>>;
