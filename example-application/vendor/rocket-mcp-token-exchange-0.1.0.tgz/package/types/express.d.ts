import type { RequestHandler } from "express";
import type { DelegatedUser, GatewayPrincipal, TokenExchangeOptions } from "./core.d.ts";

export function tokenExchangeExpress<User extends DelegatedUser = DelegatedUser, Gateway extends GatewayPrincipal = GatewayPrincipal>(
  options: TokenExchangeOptions<User, Gateway>,
): RequestHandler;

export default tokenExchangeExpress;
