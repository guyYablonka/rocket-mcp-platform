export interface ActorIdentity {
  rocketUserId: string;
  tenantId: string;
  roomId: string;
  requestId: string;
}

export interface GatewayPrincipal {
  id: string;
  [key: string]: unknown;
}

export interface DelegatedUser {
  disabled?: boolean;
  [key: string]: unknown;
}

export interface ExchangeContext {
  requestId: string;
  ip: string;
  userAgent: string;
}

export interface TokenResult {
  accessToken: string;
  tokenType?: string;
  expiresIn: number;
  scopes?: string[];
}

export interface TokenExchangeOptions<User extends DelegatedUser = DelegatedUser, Gateway extends GatewayPrincipal = GatewayPrincipal> {
  authenticateGateway(input: {
    authorization?: string;
    headers: Record<string, unknown>;
    context: ExchangeContext;
  }): Gateway | null | Promise<Gateway | null>;
  findUser(input: {
    applicationUserId: string;
    actor: ActorIdentity;
    gateway: Gateway;
    context: ExchangeContext;
  }): User | null | Promise<User | null>;
  authorizeScopes(input: {
    user: User;
    requestedScopes: string[];
    actor: ActorIdentity;
    gateway: Gateway;
    context: ExchangeContext;
  }): string[] | Promise<string[]>;
  issueToken(input: {
    user: User;
    scopes: string[];
    actor: ActorIdentity;
    gateway: Gateway;
    context: ExchangeContext;
  }): TokenResult | Promise<TokenResult>;
  audit?(event: Record<string, unknown>): void | Promise<void>;
  maxScopes?: number;
  requireActor?: boolean;
}

export interface ExchangeInput {
  headers?: Record<string, unknown>;
  body?: unknown;
  ip?: string;
}

export interface ExchangeResponse {
  status: number;
  headers: Record<string, string>;
  body: Record<string, unknown>;
}

export type TokenExchangeHandler = (input: ExchangeInput) => Promise<ExchangeResponse>;

export function createTokenExchange<User extends DelegatedUser = DelegatedUser, Gateway extends GatewayPrincipal = GatewayPrincipal>(
  options: TokenExchangeOptions<User, Gateway>,
): TokenExchangeHandler;

export function createStaticGatewayAuthenticator(options: {
  tokens: Array<string | { id: string; token: string }>;
}): (input: { authorization?: string }) => Promise<GatewayPrincipal | null>;

export const tokenExchangeRequestSchema: Readonly<Record<string, unknown>>;
